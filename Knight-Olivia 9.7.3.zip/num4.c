// 9.7.3 Number 4: An Arithmetic Series
//Knight, Olivia - February 13, 2020

#include <stdio.h>

long term(long a, long d, long k) //The function that will compute the equation of the kth term in an arithmetic series. 
{
    long arith_sum; //This variable will hold the answer provided by the equation. 
    arith_sum=a+(k-1)*d;//The equation to find the kth term
    return arith_sum; //This will return the arithsum variable so it can be used in the main function
    
}
//---------------------------------------------------//

int main(void) //The main function that will prompt a user for inputs and then use the term function to print the first 100 terms of the series
{
    long a;
    long d;
    long k; //an integer to be used as a counter.
    long kth_sum; //Will hold the value that is returned by the term function.
    
    printf("Please enter the first term in the series\n"); //Prompts the user to enter a value for the variable a
    scanf("%ld",&a);
    printf("Please enter the difference between the terms\n");//Prompts the user to enter a value for the variable d.
    scanf("%ld",&d);
    
    for(k=1;k<100;k++)
    {
        kth_sum=term(a,d,k);
        printf("%ld\t",kth_sum);
        if(k!=0&&k%5==0)
        {
            printf("\n"); //Will print a new line every 5 terms in attempts to separate the values in columns
        }
    }
    return 0; 
}
