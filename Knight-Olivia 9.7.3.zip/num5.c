//9.7.3 Number 5: A Geometric Series 
// Knight, Olivia - February 13, 2020
#include <stdio.h>
#include <math.h>

double term(double a, double R, double k) //Used to compute the kth term in a geometric series that will be used in main, 0
{
    double geo_series;
    geo_series=a*(pow(R,k-1)); //This is the equation that will find the kth term in a geometric series.
    return geo_series; //Returns the value in the geo_series variable to be used in the main function/ 
}

int main(void)
{
    double a; 
    double R; 
    int k;
    double kth_term;//The variable that will hold the value returned by the term function.

    printf("Please enter the first term of the series\n");// Asks the user to input a value for the variable a
    scanf("%lg",&a);
    printf("Please enter the common ratio\n");// Asks the user to input a value for the variable R
    scanf("%lg",&R);

    for(k=1; k<50; k++)  //Uses the term function to compute and print out the first 50 terms of a geometric series. 
    {
        kth_term=term(a,R,k);//Will carry out the term function to get the 50 values of the series
        printf("%lg\t",kth_term);
        if(k%5==0)
        {
            printf("\n");//Will print a new line so there are 5 terms per column
        }
    }
    return 0; 
}
