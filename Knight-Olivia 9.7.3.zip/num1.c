//9.7.3 Number 1: A Function
// Knight, Olivia - February 13, 2020
#include <stdio.h>
#include <math.h>

double formula(int x) //This is the formula that will be used for the main function.
{
  double ans;
  ans=sqrt((3*x)+1);
  return ans; //Returns the value of the ans variable to be used in the main function.
}
//----------------------------------------------------//

int main(void)
{
    double sum; //Will hold the value found from the formula function. 
    int b;//A counter 
    for(b=0;b<1000;b++) 
    {
      sum=formula(b); //Calls the formula function for multiple values. 
      if(b!=0&&b%50==0) //Will be used to print values 0-1000 in steps of 50.
      {
        printf("%g\n",sum);
      }
    }
    return 0;
}
