//9.7.3 Number 6: Torque
//Knight, Olivia - February 13, 2020

#include <stdio.h>
#include <math.h>

double moment(double radius, double mass) //This calculates and returns the moment of inertia using user inputted values. 
{
    double I; 
    I=(0.5)*mass*pow(radius,2); //This is the formula used to calcuate intertia
    return I; //returns the value of I to be used in the work function.
}
//-----------------------------------------------//

double work() //This prompts the user to enter values for 3 different variables to calculate the torque
{
    double radius;
    double mass;
    double angular_acceleration;
    double torque;

    printf("Enter the radius\n");
    scanf("%lg",&radius); //Will apply the user inputted value to the radius variable
    printf("Enter the mass\n");
    scanf("%lg",&mass); //Will apply the user inputted values to the mass variable 
    printf("Enter the angular acceleration\n");
    scanf("%lg",&angular_acceleration); //Will apply the user inputted value to the angular acceleration variable 

    while(radius<0.093||radius>0.207||mass<0.088||mass>11) //This will ensure that an error message will appear if the user inputs a value that doesn't fit the range.
    {
        if(radius<0.093||radius>0.207) //If the user inputs an invalid value for radius then this error message will appear 
        {
            printf("Error: Radius must be between 0.093-0.207\n");
            scanf("%lg",&radius);
        }
        if(mass<0.088||mass>11) //If the user inputs an invalid value for mass then this error message will appear. 
        {
            printf("Error: Mass must be between 0.089-11\n");
            scanf("%lg",&mass);
        }

    }
    torque=moment(radius,mass)*angular_acceleration; //Using the moment function we made to calculate the torque

    return torque; //Returns the value of the torque variable so that it can be used in main. 
}
//----------------------------------------------//

int main()
{
    int cont; //This variable will be used to ask the user to continue the program. 
    double torque;//This variable will contain the values found from the work function

    torque=work();
    printf("The torque is:%g\n",torque); //Prints out the values obtained from the work function

    printf("Press 1 to continue\n");
    scanf("%i",&cont); //Will take a value for the cont variable
    while(cont==1) //If the user inputs 1, the program will continue, if not, the program will end. 
    {
        torque=work();
        printf("The torque is:%g\n",torque);

        printf("Press 1 to continue\n");
        scanf("%i",&cont);
    }
    return 0;
}
