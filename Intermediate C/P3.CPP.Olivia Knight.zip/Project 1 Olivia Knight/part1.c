/*Olivia Knight CSCI 2212-02
    Project #1*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctype.h>
int main()
{
    srand(RAND_MAX);
    //These are the two arrays that will determine the value and the suit of the cards generated. 
    char *suits[]={"Hearts","Diamonds","Clubs","Spades"};
    char *card_val[]={"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
    
    int b,c;//These ints are used to refer to a random array index. 
    int suit_guess;//This variable will store the user input for the suit value
    int value_guess;// This variable will store the user input for the guess of the card value
    
    b=rand()%4;//This will make b a number between 0-4, which is used in the suits array.
        //printf("%s was generated.\n",suits[b]); //Testing the correctness
    c=rand()%13; //Will make c a number between 0-13 for use in the card_val array. 
       // printf("%s was generated.\n",card_val[c]); //Testing the correctness
    
    printf("Get Your Wish\n");
    printf("The genie will chose a random card! Guess the suit and value correctly and your wish will be granted!\n");
    printf("The genie has picked a card.\n Please guess the suit\n Option 1:Heart\n Option 2:Diamond\n Option 3: Club\n Option 4: Spade\n Option 5: Quit\n");
    
    scanf("%i",&suit_guess);
   
    while(suit_guess>5||suit_guess<1)
    {
        printf("Please enter a value that's within the range of options!\n");
        scanf("%i",&suit_guess);
    }
    
    if(suit_guess==5) //This will ensure that the program ends if the user enters '5' in the scan.
    {
        printf("Thank you for playing!\n");
        return 0;
    }
    
    while(suit_guess!=b)//Will ask the user for more inputs if the option they chose isn't the same as the value of b
    {
        printf("Sorry! That's not correct. Please try again!\n");
        printf("Option 1:Heart\n Option 2:Diamond\n Option 3: Club\n Option 4: Spade\n Option 5: Quit\n");
        scanf("%i",&suit_guess);
        
        if(suit_guess==5) //This will ensure that the program ends if the user enters '5' in the scan.
        {
            printf("Thank you for playing!\n");
            return 0;
        }
        while(suit_guess>5||suit_guess<1)
         {
            printf("Please enter a value that's within the range of options!\n");
            scanf("%i",&suit_guess);
         }
    }
    
    if(suit_guess==b) //Will move on to asking the user to guess the card value if the suit guess is equivalent to b.
    {
        printf("Correct! Now guess the card value!\n");
        printf("Option 1:Ace\n Option 2:Two\n Option 3:Three\n Option 4:Four\n Option 5:Five\n Option 6: Six\n Option 7: Seven\n Option 8:Eight\n Option 9: Nine\n Option 10: Ten\n Option 11:Jack\n Option 12:Queen\n Option 13:King\n Option 14: Quit\n");
        scanf("%i",&value_guess);
        
        while(value_guess>14||value_guess<1)
        {
            printf("Please enter a value that is within the range of options!\n");
            scanf("%i",&value_guess);
        }
        
        if(value_guess==14)//Ends the program if the user inputs 14 for the value. 
        {
            printf("Thank you for playing!\n");
            return 0;
        }
        
        while(value_guess!=c)//Will continually ask the user for more inputs if it doesn't match the value of c
        {
             printf("Sorry! That's not correct. Please try again!\n");
             printf("Option 1:Ace\n Option 2:Two\n Option 3:Three\n Option 4:Four\n Option 5:Five\n Option 6: Six\n Option 7: Seven\n Option 8:Eight\n Option 9: Nine\n Option 10: Ten\n Option 11:Jack\n Option 12:Queen\n Option 13:King\n Option 14: Quit\n");
             scanf("%i",&value_guess);
             
             if(value_guess==14)//Ends the program if the user inputs 14 for the value. 
             {
                printf("Thank you for playing!\n");
                return 0;
             }
              if(value_guess>14||value_guess<1)
            {
                printf("Please enter a value that is within the range of options!\n");
                scanf("%i",&value_guess);
            }
        }
        if(value_guess==c)//Will print a congratulatory message if the user inputs an equivalent value for b and c. 
        {
            printf("Correct!\n");
            printf("For correctly guessing the card: %s of %s, the genie will now grant your wish!\n",card_val[c],suits[b]);
            printf("Thanks for playing!\n");
            return 0; 
        }
        
    }
    return 0;
}